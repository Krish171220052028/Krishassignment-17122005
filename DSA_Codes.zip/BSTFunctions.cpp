
#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
    Node(int v): data(v), left(NULL), right(NULL) {}
};

Node* insertNode(Node* root, int key) {
    if (!root) return new Node(key);
    if (key < root->data) root->left = insertNode(root->left, key);
    else if (key > root->data) root->right = insertNode(root->right, key);
    return root;
}

bool searchRec(Node* root, int key) {
    if (!root) return false;
    if (root->data == key) return true;
    if (key < root->data) return searchRec(root->left, key);
    else return searchRec(root->right, key);
}

bool searchNonRec(Node* root, int key) {
    while (root) {
        if (root->data == key) return true;
        if (key < root->data) root = root->left;
        else root = root->right;
    }
    return false;
}

int minVal(Node* root) {
    while (root->left) root = root->left;
    return root->data;
}

int maxVal(Node* root) {
    while (root->right) root = root->right;
    return root->data;
}

Node* inorderSuccessor(Node* root, Node* target) {
    Node* succ = NULL;
    while (root) {
        if (target->data < root->data) {
            succ = root;
            root = root->left;
        } else root = root->right;
    }
    return succ;
}

Node* inorderPredecessor(Node* root, Node* target) {
    Node* pred = NULL;
    while (root) {
        if (target->data > root->data) {
            pred = root;
            root = root->right;
        } else root = root->left;
    }
    return pred;
}

int main() {
    Node* root = NULL;
    root = insertNode(root, 20);
    insertNode(root, 10);
    insertNode(root, 30);

    cout << searchRec(root, 10);
}
