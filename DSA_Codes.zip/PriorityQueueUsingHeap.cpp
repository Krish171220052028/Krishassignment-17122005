
#include <iostream>
using namespace std;

class PriorityQueue {
    int a[100];
    int size;
public:
    PriorityQueue(): size(0) {}

    void push(int x) {
        a[size] = x;
        int i = size;
        size++;
        while (i > 0 && a[(i-1)/2] < a[i]) {
            swap(a[i], a[(i-1)/2]);
            i = (i-1)/2;
        }
    }

    int pop() {
        int top = a[0];
        a[0] = a[size-1];
        size--;
        int i = 0;
        while (true) {
            int l = 2*i+1, r = 2*i+2, largest = i;
            if (l < size && a[l] > a[largest]) largest = l;
            if (r < size && a[r] > a[largest]) largest = r;
            if (largest != i) {
                swap(a[i], a[largest]);
                i = largest;
            } else break;
        }
        return top;
    }
};

int main() {
    PriorityQueue pq;
    pq.push(30);
    pq.push(10);
    pq.push(50);
    cout << pq.pop();
}
