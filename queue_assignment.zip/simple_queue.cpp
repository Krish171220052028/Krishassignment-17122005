
#include <bits/stdc++.h>
using namespace std;

#define MAX 100

class Queue {
    int arr[MAX], front, rear;
public:
    Queue() { front = -1; rear = -1; }

    bool isEmpty() { return front == -1; }
    bool isFull() { return rear == MAX - 1; }

    void enqueue(int x) {
        if(isFull()) { cout<<"Queue Full\n"; return; }
        if(front == -1) front = 0;
        arr[++rear] = x;
    }

    void dequeue() {
        if(isEmpty()) { cout<<"Queue Empty\n"; return; }
        cout<<"Dequeued: "<<arr[front]<<"\n";
        if(front == rear) front = rear = -1;
        else front++;
    }

    void peek() {
        if(isEmpty()) { cout<<"Queue Empty\n"; return; }
        cout<<"Front: "<<arr[front]<<"\n";
    }

    void display() {
        if(isEmpty()) { cout<<"Queue Empty\n"; return; }
        for(int i=front;i<=rear;i++) cout<<arr[i]<<" ";
        cout<<"\n";
    }
};

int main(){
    Queue q;
    int ch, val;
    while(true){
        cin>>ch;
        if(ch==1){ cin>>val; q.enqueue(val); }
        else if(ch==2) q.dequeue();
        else if(ch==3) q.peek();
        else if(ch==4) q.display();
        else break;
    }
}
