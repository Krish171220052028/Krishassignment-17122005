
#include <bits/stdc++.h>
using namespace std;

class Stack {
    queue<int> q;
public:
    void push(int x){
        q.push(x);
        for(int i=0;i<q.size()-1;i++){
            q.push(q.front());
            q.pop();
        }
    }

    void pop(){
        if(!q.empty()) q.pop();
    }

    int top(){
        return q.empty() ? -1 : q.front();
    }

    bool empty(){ return q.empty(); }
};

int main(){
    Stack s;
    int ch,x;
    while(cin>>ch){
        if(ch==1){ cin>>x; s.push(x); }
        else if(ch==2) s.pop();
        else if(ch==3) cout<<s.top()<<" ";
        else break;
    }
}
