
#include <bits/stdc++.h>
using namespace std;

int main(){
    queue<int> q;
    int x;
    while(cin>>x) q.push(x);

    int n = q.size();
    queue<int> first;
    for(int i=0;i<n/2;i++){
        first.push(q.front());
        q.pop();
    }

    while(!first.empty()){
        cout<<first.front()<<" "<<q.front()<<" ";
        first.pop(); q.pop();
    }
}
