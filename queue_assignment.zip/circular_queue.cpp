
#include <bits/stdc++.h>
using namespace std;

#define MAX 100

class CQueue {
    int arr[MAX], front, rear, cnt;
public:
    CQueue() { front = rear = cnt = 0; }

    bool isEmpty(){ return cnt==0; }
    bool isFull(){ return cnt==MAX; }

    void enqueue(int x){
        if(isFull()){ cout<<"Full\n"; return; }
        arr[rear] = x;
        rear = (rear+1)%MAX;
        cnt++;
    }

    void dequeue(){
        if(isEmpty()){ cout<<"Empty\n"; return; }
        cout<<"Dequeued: "<<arr[front]<<"\n";
        front = (front+1)%MAX;
        cnt--;
    }

    void peek(){
        if(isEmpty()){ cout<<"Empty\n"; return; }
        cout<<"Front: "<<arr[front]<<"\n";
    }

    void display(){
        if(isEmpty()){ cout<<"Empty\n"; return; }
        int idx=front;
        for(int i=0;i<cnt;i++){
            cout<<arr[idx]<<" ";
            idx=(idx+1)%MAX;
        }
        cout<<"\n";
    }
};

int main(){
    CQueue q;
    int ch,val;
    while(true){
        cin>>ch;
        if(ch==1){ cin>>val; q.enqueue(val); }
        else if(ch==2) q.dequeue();
        else if(ch==3) q.peek();
        else if(ch==4) q.display();
        else break;
    }
}
