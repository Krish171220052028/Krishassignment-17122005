
#include <bits/stdc++.h>
using namespace std;

struct DSU{
    vector<int> par, sz;
    DSU(int n){ par.resize(n); sz.assign(n,1); for(int i=0;i<n;i++) par[i]=i; }
    int find(int x){ return par[x]==x?x:par[x]=find(par[x]); }
    bool unite(int a,int b){
        a=find(a); b=find(b);
        if(a==b) return false;
        if(sz[a]<sz[b]) swap(a,b);
        par[b]=a; sz[a]+=sz[b];
        return true;
    }
};

int main(){
    int V,E; cin>>V>>E;
    vector<array<int,3>> edges;
    for(int i=0;i<E;i++){
        int u,v,w; cin>>u>>v>>w;
        edges.push_back({w,u,v});
    }
    sort(edges.begin(), edges.end());
    DSU d(V);
    int mst=0;
    for(auto &e:edges){
        if(d.unite(e[1],e[2])) mst+=e[0];
    }
    cout<<mst;
}
