
#include <bits/stdc++.h>
using namespace std;

void dfs(int x,int y, vector<vector<int>>& g, int m,int n){
    if(x<0||y<0||x>=m||y>=n||g[x][y]==0) return;
    g[x][y]=0;
    dfs(x+1,y,g,m,n);
    dfs(x-1,y,g,m,n);
    dfs(x,y+1,g,m,n);
    dfs(x,y-1,g,m,n);
}

int main(){
    int m,n; cin>>m>>n;
    vector<vector<int>> g(m, vector<int>(n));
    for(int i=0;i<m;i++) for(int j=0;j<n;j++) cin>>g[i][j];
    int count=0;
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            if(g[i][j]==1){
                count++;
                dfs(i,j,g,m,n);
            }
        }
    }
    cout<<count;
}
