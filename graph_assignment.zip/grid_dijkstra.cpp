
#include <bits/stdc++.h>
using namespace std;

int main(){
    int m,n; cin>>m>>n;
    vector<vector<int>> grid(m, vector<int>(n));
    for(int i=0;i<m;i++) for(int j=0;j<n;j++) cin>>grid[i][j];

    vector<vector<int>> dist(m, vector<int>(n,1e9));
    priority_queue<array<int,3>, vector<array<int,3>>, greater<array<int,3>>> pq;

    dist[0][0]=grid[0][0];
    pq.push({grid[0][0],0,0});

    int dirs[4][2]={{1,0},{-1,0},{0,1},{0,-1}};

    while(!pq.empty()){
        auto [d,x,y]=pq.top(); pq.pop();
        if(d!=dist[x][y]) continue;
        for(auto &dir:dirs){
            int nx=x+dir[0], ny=y+dir[1];
            if(nx>=0 && ny>=0 && nx<m && ny<n){
                int nd=d+grid[nx][ny];
                if(nd < dist[nx][ny]){
                    dist[nx][ny]=nd;
                    pq.push({nd,nx,ny});
                }
            }
        }
    }
    cout<<dist[m-1][n-1];
}
