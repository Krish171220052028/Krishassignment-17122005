
#include <bits/stdc++.h>
using namespace std;

int main(){
    int N,E; cin>>N>>E;
    vector<vector<pair<int,int>>> adj(N+1);
    for(int i=0;i<E;i++){
        int u,v,w; cin>>u>>v>>w;
        adj[u].push_back({v,w});
    }
    int K; cin>>K;

    vector<int> dist(N+1,1e9);
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> pq;
    dist[K]=0; pq.push({0,K});

    while(!pq.empty()){
        auto [d,u]=pq.top(); pq.pop();
        if(d!=dist[u]) continue;
        for(auto &p:adj[u]){
            int v=p.first, w=p.second;
            if(dist[u]+w < dist[v]){
                dist[v]=dist[u]+w;
                pq.push({dist[v],v});
            }
        }
    }

    int ans=*max_element(dist.begin()+1, dist.end());
    cout<<(ans>=1e9?-1:ans);
}
