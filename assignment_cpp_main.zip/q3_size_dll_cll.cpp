// Q3: Find size of Doubly Linked List and Circular Linked List
#include <bits/stdc++.h>
using namespace std;
struct DNode{ int data; DNode *prev,*next; DNode(int v):data(v),prev(nullptr),next(nullptr){} };
int sizeDLL(DNode* head){
    int cnt=0;
    while(head){ cnt++; head = head->next; }
    return cnt;
}
struct CNode{ int data; CNode* next; CNode(int v):data(v),next(nullptr){} };
int sizeCLL(CNode* tail){
    if(!tail) return 0;
    int cnt=0;
    CNode* cur = tail->next;
    do { cnt++; cur = cur->next; } while(cur != tail->next);
    return cnt;
}
int main(){
    // Example usage: read sizes by constructing simple lists
    int n;
    cout<<"Enter number of nodes for DLL: ";
    if(!(cin>>n) || n<0) return 0;
    DNode* head=nullptr; DNode* tail=nullptr;
    for(int i=0;i<n;i++){
        int v; cin>>v;
        DNode* node = new DNode(v);
        if(!head) head = tail = node;
        else { tail->next = node; node->prev = tail; tail = node; }
    }
    cout<<"DLL size = "<<sizeDLL(head)<<"\n";
    cout<<"Enter number of nodes for CLL: ";
    if(!(cin>>n) || n<0) return 0;
    CNode* tailc=nullptr;
    for(int i=0;i<n;i++){
        int v; cin>>v;
        CNode* node=new CNode(v);
        if(!tailc){ tailc=node; node->next=node; }
        else { node->next = tailc->next; tailc->next = node; tailc=node; }
    }
    cout<<"CLL size = "<<sizeCLL(tailc)<<"\n";
    return 0;
}
