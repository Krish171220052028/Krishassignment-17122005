// Q4: Check if a doubly linked list of characters is palindrome
#include <bits/stdc++.h>
using namespace std;
struct DNode{ char data; DNode *prev,*next; DNode(char c):data(c),prev(nullptr),next(nullptr){} };
bool isPalindrome(DNode* head){
    if(!head) return true;
    DNode* tail = head;
    while(tail->next) tail = tail->next;
    while(head && tail && head!=tail && head->prev!=tail){
        if(head->data != tail->data) return false;
        head = head->next; tail = tail->prev;
    }
    return true;
}
int main(){
    cout<<"Enter a string (no spaces): ";
    string s; if(!(cin>>s)) return 0;
    DNode* head=nullptr; DNode* tail=nullptr;
    for(char c: s){
        DNode* node = new DNode(c);
        if(!head) head = tail = node;
        else { tail->next = node; node->prev = tail; tail = node; }
    }
    cout<<(isPalindrome(head) ? "True\n" : "False\n");
    return 0;
}
