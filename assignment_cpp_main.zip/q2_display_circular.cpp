// Q2: Display circular linked list values repeating head at end.
// Input example: 20 100 40 80 60 (5 numbers) -> Output: 20 100 40 80 60 20
#include <bits/stdc++.h>
using namespace std;
struct Node { int data; Node* next; Node(int v):data(v),next(nullptr){} };
int main(){
    int n;
    cout<<"Enter number of nodes: ";
    if(!(cin>>n) || n<=0) return 0;
    vector<int> a(n);
    for(int i=0;i<n;i++) cin>>a[i];
    // build circular
    Node *head=nullptr, *tail=nullptr;
    for(int v: a){
        Node* node=new Node(v);
        if(!head) head = tail = node, tail->next = head;
        else { tail->next = node; tail = node; tail->next = head; }
    }
    // display including head again
    if(!head) return 0;
    Node* cur = head;
    do { cout<<cur->data<<" "; cur = cur->next; } while(cur!=head);
    // print head again
    cout<<head->data<<"\n";
    return 0;
}
