// Q5: Check if a linked list is circular (detect if last node points back)
// We'll implement detection using Floyd's cycle-finding algorithm.
// Input: first number n (nodes), then n numbers; optionally you can create a cycle by specifying pos (index of node tail should point to; -1 for no cycle)
#include <bits/stdc++.h>
using namespace std;
struct Node{ int data; Node* next; Node(int v):data(v),next(nullptr){} };
bool isCircular(Node* head){
    if(!head) return false;
    Node* slow = head, *fast = head;
    while(fast && fast->next){
        slow = slow->next;
        fast = fast->next->next;
        if(slow == fast) return true;
    }
    return false;
}
int main(){
    int n; cout<<"n: "; if(!(cin>>n) || n<=0) return 0;
    vector<Node*> nodes;
    for(int i=0;i<n;i++){ int v; cin>>v; nodes.push_back(new Node(v)); if(i) nodes[i-1]->next = nodes[i]; }
    cout<<"Enter cycle position (0-based index, -1 for none): ";
    int pos; cin>>pos;
    if(pos>=0 && pos<n) nodes.back()->next = nodes[pos];
    cout<<(isCircular(nodes[0]) ? "True\n" : "False\n");
    return 0;
}
