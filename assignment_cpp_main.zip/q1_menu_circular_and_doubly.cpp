// Q1: Menu driven for Circular Singly Linked List and Doubly Linked List
// Simple implementation with insertion (first, last, after value), deletion (by value), and search.
// Compile: g++ q1_menu_circular_and_doubly.cpp -o q1 && ./q1

#include <bits/stdc++.h>
using namespace std;

// ---------- Circular Singly Linked List ----------
struct CNode {
    int data;
    CNode* next;
    CNode(int v): data(v), next(nullptr) {}
};

class CircularList {
    CNode* tail; // tail->next is head
public:
    CircularList(): tail(nullptr) {}
    void insertFirst(int v) {
        CNode* node = new CNode(v);
        if (!tail) { tail = node; node->next = node; }
        else { node->next = tail->next; tail->next = node; }
    }
    void insertLast(int v) {
        insertFirst(v);
        tail = tail->next;
    }
    bool insertAfter(int afterVal, int v) {
        if(!tail) return false;
        CNode* cur = tail->next;
        do {
            if(cur->data == afterVal) {
                CNode* node = new CNode(v);
                node->next = cur->next;
                cur->next = node;
                if(cur == tail) tail = node;
                return true;
            }
            cur = cur->next;
        } while(cur != tail->next);
        return false;
    }
    bool removeValue(int v) {
        if(!tail) return false;
        CNode *cur = tail->next, *prev = tail;
        do {
            if(cur->data == v) {
                if(cur == prev) { // only one node
                    delete cur; tail = nullptr; return true;
                }
                prev->next = cur->next;
                if(cur == tail) tail = prev;
                delete cur;
                return true;
            }
            prev = cur; cur = cur->next;
        } while(cur != tail->next);
        return false;
    }
    bool search(int v) {
        if(!tail) return false;
        CNode* cur = tail->next;
        do {
            if(cur->data == v) return true;
            cur = cur->next;
        } while(cur != tail->next);
        return false;
    }
    void display() {
        if(!tail) { cout<<"Empty\n"; return; }
        CNode* cur = tail->next;
        do {
            cout<<cur->data<<" ";
            cur = cur->next;
        } while(cur != tail->next);
        cout<<"\n";
    }
};

// ---------- Doubly Linked List ----------
struct DNode {
    int data;
    DNode* prev; DNode* next;
    DNode(int v): data(v), prev(nullptr), next(nullptr) {}
};

class DoublyList {
    DNode* head;
public:
    DoublyList(): head(nullptr) {}
    void insertFirst(int v) {
        DNode* node = new DNode(v);
        node->next = head;
        if(head) head->prev = node;
        head = node;
    }
    void insertLast(int v) {
        if(!head) { insertFirst(v); return; }
        DNode* cur = head;
        while(cur->next) cur = cur->next;
        DNode* node = new DNode(v);
        cur->next = node; node->prev = cur;
    }
    bool insertAfter(int afterVal, int v) {
        DNode* cur = head;
        while(cur) {
            if(cur->data == afterVal) {
                DNode* node = new DNode(v);
                node->next = cur->next;
                node->prev = cur;
                if(cur->next) cur->next->prev = node;
                cur->next = node;
                return true;
            }
            cur = cur->next;
        }
        return false;
    }
    bool removeValue(int v) {
        DNode* cur = head;
        while(cur) {
            if(cur->data == v) {
                if(cur->prev) cur->prev->next = cur->next;
                else head = cur->next;
                if(cur->next) cur->next->prev = cur->prev;
                delete cur;
                return true;
            }
            cur = cur->next;
        }
        return false;
    }
    bool search(int v) {
        DNode* cur = head;
        while(cur) { if(cur->data==v) return true; cur = cur->next; }
        return false;
    }
    void display() {
        if(!head) { cout<<"Empty\n"; return; }
        DNode* cur = head;
        while(cur) { cout<<cur->data<<" "; cur = cur->next; }
        cout<<"\n";
    }
};

// ---------- Menu ----------
int main() {
    CircularList cll;
    DoublyList dll;
    int choice;
    while(true) {
        cout<<"\n===== Assignment Q1 Menu =====\n";
        cout<<"1. CLL: insert first\n2. CLL: insert last\n3. CLL: insert after value\n4. CLL: delete value\n5. CLL: search\n6. CLL: display\n7. DLL: insert first\n8. DLL: insert last\n9. DLL: insert after value\n10. DLL: delete value\n11. DLL: search\n12. DLL: display\n0. Exit\nChoose: ";
        if(!(cin>>choice)) break;
        if(choice==0) break;
        int x, y;
        bool ok;
        switch(choice) {
            case 1: cout<<"value: "; cin>>x; cll.insertFirst(x); break;
            case 2: cout<<"value: "; cin>>x; cll.insertLast(x); break;
            case 3: cout<<"after value and new value: "; cin>>x>>y; ok=cll.insertAfter(x,y); cout<<(ok?"Inserted\n":"Not found\n"); break;
            case 4: cout<<"value to delete: "; cin>>x; ok=cll.removeValue(x); cout<<(ok?"Deleted\n":"Not found\n"); break;
            case 5: cout<<"value to search: "; cin>>x; cout<<(cll.search(x)?"Found\n":"Not found\n"); break;
            case 6: cout<<"CLL: "; cll.display(); break;
            case 7: cout<<"value: "; cin>>x; dll.insertFirst(x); break;
            case 8: cout<<"value: "; cin>>x; dll.insertLast(x); break;
            case 9: cout<<"after value and new value: "; cin>>x>>y; ok=dll.insertAfter(x,y); cout<<(ok?"Inserted\n":"Not found\n"); break;
            case 10: cout<<"value to delete: "; cin>>x; ok=dll.removeValue(x); cout<<(ok?"Deleted\n":"Not found\n"); break;
            case 11: cout<<"value to search: "; cin>>x; cout<<(dll.search(x)?"Found\n":"Not found\n"); break;
            case 12: cout<<"DLL: "; dll.display(); break;
            default: cout<<"Invalid\n";
        }
    }
    return 0;
}
