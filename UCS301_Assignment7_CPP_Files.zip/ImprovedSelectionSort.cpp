#include <iostream>
using namespace std;

void improvedSelectionSort(int arr[], int n) {
    for (int i = 0; i < n / 2; i++) {
        int minIndex = i;
        int maxIndex = i;
        for (int j = i + 1; j < n - i; j++) {
            if (arr[j] < arr[minIndex]) minIndex = j;
            if (arr[j] > arr[maxIndex]) maxIndex = j;
        }
        swap(arr[i], arr[minIndex]);
        if (maxIndex == i) maxIndex = minIndex;
        swap(arr[n - i - 1], arr[maxIndex]);
    }
}

int main() {
    int arr[] = {5, 2, 9, 1, 5, 6};
    int n = sizeof(arr) / sizeof(arr[0]);
    improvedSelectionSort(arr, n);
    cout << "Improved Selection Sorted array: ";
    for (int i = 0; i < n; i++) cout << arr[i] << " ";
    return 0;
}